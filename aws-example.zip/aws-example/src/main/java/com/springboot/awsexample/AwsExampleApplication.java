package com.springboot.awsexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsExampleApplication.class, args);
	}

}
