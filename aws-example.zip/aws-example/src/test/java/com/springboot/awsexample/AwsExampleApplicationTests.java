package com.springboot.awsexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
